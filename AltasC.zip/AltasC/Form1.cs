﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AltasC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            string userCheck;

            const string DATA_FILE = "UserInfo.txt";

            FileStream fsIn = new FileStream(DATA_FILE, FileMode.Open, FileAccess.Read);
            StreamReader srIn = new StreamReader(fsIn);

            // Open the login information file and create a StreamReader object to read from it
            StreamReader reader = new StreamReader("UserInfo.txt");

            // Read the contents of the file into a string variable
            string fileContents = reader.ReadToEnd();

            // Close the file
            reader.Close();

            // Split the contents of the file into an array of strings, using the newline character as the delimiter
            string[] lines = fileContents.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

            // Ask the user to enter their username
            Console.Write("Please enter your username: ");
            userCheck = txtID.Text;

            // Loop through each line of the file to find the matching username
            bool usernameFound = false;
            foreach (string line in lines)
            {
                // Split each line into two parts: the username and the password (separated by a comma)
                string[] parts = line.Split(',');

                // Check if the first part (the username) matches the user's input
                if (parts[0] == userCheck)
                {
                    // If a match is found, set the flag and break out of the loop
                    usernameFound = true;
                    break;
                }
            }

            // Display a message based on whether or not the username was found
            if (usernameFound)
            {
                this.Hide();

                Form2 menuSelection = new Form2();
                menuSelection.Show();
            }
            else
            {
                MessageBox.Show("Not found");
            }
            //this.Hide();
            //Form2 comboSelection = new Form2();
            //comboSelection.Show();
        }
    }
}
