﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AltasC
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnComfirm_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 dateSelection = new Form3();
            dateSelection.Show();


            //MessageBox.Show("{0} Combo A Selected \n {1} Combo B Selected \n {2} Combo C Selected", ComboA.Text, ComboB.Text, ComboC.Text);
        }


        private void rabtnComboA_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
