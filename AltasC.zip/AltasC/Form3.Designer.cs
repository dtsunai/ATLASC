﻿
namespace AltasC
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ch2am = new System.Windows.Forms.CheckBox();
            this.ch11pm = new System.Windows.Forms.CheckBox();
            this.ch8pm = new System.Windows.Forms.CheckBox();
            this.ch1am = new System.Windows.Forms.CheckBox();
            this.ch10pm = new System.Windows.Forms.CheckBox();
            this.ch7pm = new System.Windows.Forms.CheckBox();
            this.ch12am = new System.Windows.Forms.CheckBox();
            this.ch9pm = new System.Windows.Forms.CheckBox();
            this.ch6pm = new System.Windows.Forms.CheckBox();
            this.lblSelectTime = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnComfirm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ch2am
            // 
            this.ch2am.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch2am.AutoSize = true;
            this.ch2am.Location = new System.Drawing.Point(637, 377);
            this.ch2am.Name = "ch2am";
            this.ch2am.Size = new System.Drawing.Size(70, 17);
            this.ch2am.TabIndex = 6;
            this.ch2am.Text = "2:00 a.m.";
            this.ch2am.UseVisualStyleBackColor = true;
            // 
            // ch11pm
            // 
            this.ch11pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch11pm.AutoSize = true;
            this.ch11pm.Location = new System.Drawing.Point(637, 322);
            this.ch11pm.Name = "ch11pm";
            this.ch11pm.Size = new System.Drawing.Size(76, 17);
            this.ch11pm.TabIndex = 7;
            this.ch11pm.Text = "11:00 p.m.";
            this.ch11pm.UseVisualStyleBackColor = true;
            // 
            // ch8pm
            // 
            this.ch8pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch8pm.AutoSize = true;
            this.ch8pm.Location = new System.Drawing.Point(637, 265);
            this.ch8pm.Name = "ch8pm";
            this.ch8pm.Size = new System.Drawing.Size(70, 17);
            this.ch8pm.TabIndex = 8;
            this.ch8pm.Text = "8:00 p.m.";
            this.ch8pm.UseVisualStyleBackColor = true;
            // 
            // ch1am
            // 
            this.ch1am.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch1am.AutoSize = true;
            this.ch1am.Location = new System.Drawing.Point(543, 377);
            this.ch1am.Name = "ch1am";
            this.ch1am.Size = new System.Drawing.Size(70, 17);
            this.ch1am.TabIndex = 9;
            this.ch1am.Text = "1:00 a.m.";
            this.ch1am.UseVisualStyleBackColor = true;
            // 
            // ch10pm
            // 
            this.ch10pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch10pm.AutoSize = true;
            this.ch10pm.Location = new System.Drawing.Point(543, 322);
            this.ch10pm.Name = "ch10pm";
            this.ch10pm.Size = new System.Drawing.Size(76, 17);
            this.ch10pm.TabIndex = 10;
            this.ch10pm.Text = "10:00 p.m.";
            this.ch10pm.UseVisualStyleBackColor = true;
            // 
            // ch7pm
            // 
            this.ch7pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch7pm.AutoSize = true;
            this.ch7pm.Location = new System.Drawing.Point(543, 265);
            this.ch7pm.Name = "ch7pm";
            this.ch7pm.Size = new System.Drawing.Size(70, 17);
            this.ch7pm.TabIndex = 11;
            this.ch7pm.Text = "7:00 p.m.";
            this.ch7pm.UseVisualStyleBackColor = true;
            // 
            // ch12am
            // 
            this.ch12am.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch12am.AutoSize = true;
            this.ch12am.Location = new System.Drawing.Point(456, 377);
            this.ch12am.Name = "ch12am";
            this.ch12am.Size = new System.Drawing.Size(76, 17);
            this.ch12am.TabIndex = 12;
            this.ch12am.Text = "12:00 a.m.";
            this.ch12am.UseVisualStyleBackColor = true;
            // 
            // ch9pm
            // 
            this.ch9pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch9pm.AutoSize = true;
            this.ch9pm.Location = new System.Drawing.Point(456, 322);
            this.ch9pm.Name = "ch9pm";
            this.ch9pm.Size = new System.Drawing.Size(70, 17);
            this.ch9pm.TabIndex = 13;
            this.ch9pm.Text = "9:00 p.m.";
            this.ch9pm.UseVisualStyleBackColor = true;
            // 
            // ch6pm
            // 
            this.ch6pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ch6pm.AutoSize = true;
            this.ch6pm.Location = new System.Drawing.Point(456, 265);
            this.ch6pm.Name = "ch6pm";
            this.ch6pm.Size = new System.Drawing.Size(70, 17);
            this.ch6pm.TabIndex = 14;
            this.ch6pm.Text = "6:00 p.m.";
            this.ch6pm.UseVisualStyleBackColor = true;
            // 
            // lblSelectTime
            // 
            this.lblSelectTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSelectTime.AutoSize = true;
            this.lblSelectTime.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectTime.Location = new System.Drawing.Point(452, 141);
            this.lblSelectTime.Name = "lblSelectTime";
            this.lblSelectTime.Size = new System.Drawing.Size(255, 22);
            this.lblSelectTime.TabIndex = 15;
            this.lblSelectTime.Text = "Please Select Desired Date and Time";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker1.Location = new System.Drawing.Point(456, 203);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(251, 20);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // btnComfirm
            // 
            this.btnComfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnComfirm.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComfirm.Location = new System.Drawing.Point(615, 439);
            this.btnComfirm.Name = "btnComfirm";
            this.btnComfirm.Size = new System.Drawing.Size(92, 31);
            this.btnComfirm.TabIndex = 25;
            this.btnComfirm.Text = "Confirm";
            this.btnComfirm.UseVisualStyleBackColor = true;
            this.btnComfirm.Click += new System.EventHandler(this.btnComfirm_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1168, 656);
            this.Controls.Add(this.btnComfirm);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblSelectTime);
            this.Controls.Add(this.ch2am);
            this.Controls.Add(this.ch11pm);
            this.Controls.Add(this.ch8pm);
            this.Controls.Add(this.ch1am);
            this.Controls.Add(this.ch10pm);
            this.Controls.Add(this.ch7pm);
            this.Controls.Add(this.ch12am);
            this.Controls.Add(this.ch9pm);
            this.Controls.Add(this.ch6pm);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox ch2am;
        private System.Windows.Forms.CheckBox ch11pm;
        private System.Windows.Forms.CheckBox ch8pm;
        private System.Windows.Forms.CheckBox ch1am;
        private System.Windows.Forms.CheckBox ch10pm;
        private System.Windows.Forms.CheckBox ch7pm;
        private System.Windows.Forms.CheckBox ch12am;
        private System.Windows.Forms.CheckBox ch9pm;
        private System.Windows.Forms.CheckBox ch6pm;
        private System.Windows.Forms.Label lblSelectTime;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnComfirm;
    }
}