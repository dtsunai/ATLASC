﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AltasC
{
    public partial class Form2 : Form
    {
        private string userInput;
        public Form2(string userInput)
        {
            InitializeComponent();
            this.userInput = userInput;
        }

        private void btnComfirm_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 dateSelection = new Form3(userInput);
            dateSelection.Show();

            if (chComboA.Checked)
            {


                if (chComboA.Checked  && chComboB.Checked )
                {
                    MessageBox.Show(ComboA.Text + " Combo A Selected" + "\n" + ComboB.Text + " Combo B Selected");
                }
                else if (chComboA.Checked && chComboC.Checked )
                {
                    MessageBox.Show(ComboA.Text + " Combo A Selected" + "\n" + ComboC.Text + " Combo C Selected");
                }
                else if (chComboA.Checked  && chComboB.Checked  && chComboC.Checked )
                {
                    MessageBox.Show(ComboA.Text + " Combo A Selected" + "\n" + ComboB.Text + " Combo B Selected" + "\n" + ComboC.Text + " Combo C Selected");
                }
                else if (chComboA.Checked)
                {
                    MessageBox.Show(ComboA.Text + " Combo A Selected");
                }
            }

            else if (chComboB.Checked)
            {
                if (chComboB.Checked  && chComboC.Checked)
                {
                    MessageBox.Show(ComboB.Text + " Combo B Selected" + "\n" + ComboC.Text + " Combo C Selected");
                }
                else if (chComboB.Checked)
                {
                    MessageBox.Show(ComboB.Text + " Combo B Selected");
                }
            }
            else if (chComboC.Checked)
            {
                MessageBox.Show(ComboC.Text + " Combo C Selected");
            }
        }


        private void rabtnComboA_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
