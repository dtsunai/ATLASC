﻿
namespace AltasC
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReservation = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTotalPrice = new System.Windows.Forms.Label();
            this.lblComboSelection = new System.Windows.Forms.Label();
            this.lblPartySize = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblUserDisplay = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblReservation
            // 
            this.lblReservation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblReservation.AutoSize = true;
            this.lblReservation.Font = new System.Drawing.Font("Papyrus", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReservation.Location = new System.Drawing.Point(501, 74);
            this.lblReservation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReservation.Name = "lblReservation";
            this.lblReservation.Size = new System.Drawing.Size(410, 54);
            this.lblReservation.TabIndex = 0;
            this.lblReservation.Text = "Reservation Confirmation";
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnEdit.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(511, 786);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(207, 41);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Text = "Cancel Reservation";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExit.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(820, 786);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(111, 41);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Confirm";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblTotalPrice
            // 
            this.lblTotalPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTotalPrice.AutoSize = true;
            this.lblTotalPrice.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPrice.Location = new System.Drawing.Point(820, 676);
            this.lblTotalPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalPrice.Name = "lblTotalPrice";
            this.lblTotalPrice.Size = new System.Drawing.Size(95, 27);
            this.lblTotalPrice.TabIndex = 3;
            this.lblTotalPrice.Text = "Total Price";
            // 
            // lblComboSelection
            // 
            this.lblComboSelection.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblComboSelection.AutoSize = true;
            this.lblComboSelection.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComboSelection.Location = new System.Drawing.Point(505, 251);
            this.lblComboSelection.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblComboSelection.Name = "lblComboSelection";
            this.lblComboSelection.Size = new System.Drawing.Size(131, 27);
            this.lblComboSelection.TabIndex = 3;
            this.lblComboSelection.Text = "Menu Selection";
            // 
            // lblPartySize
            // 
            this.lblPartySize.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPartySize.AutoSize = true;
            this.lblPartySize.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPartySize.Location = new System.Drawing.Point(829, 165);
            this.lblPartySize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPartySize.Name = "lblPartySize";
            this.lblPartySize.Size = new System.Drawing.Size(90, 27);
            this.lblPartySize.TabIndex = 3;
            this.lblPartySize.Text = "Party Size";
            // 
            // lblUserName
            // 
            this.lblUserName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Location = new System.Drawing.Point(505, 165);
            this.lblUserName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(100, 27);
            this.lblUserName.TabIndex = 3;
            this.lblUserName.Text = "User Name";
            this.lblUserName.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblUserDisplay
            // 
            this.lblUserDisplay.AutoSize = true;
            this.lblUserDisplay.Location = new System.Drawing.Point(268, 170);
            this.lblUserDisplay.Name = "lblUserDisplay";
            this.lblUserDisplay.Size = new System.Drawing.Size(44, 16);
            this.lblUserDisplay.TabIndex = 4;
            this.lblUserDisplay.Text = "label1";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1568, 998);
            this.Controls.Add(this.lblUserDisplay);
            this.Controls.Add(this.lblTotalPrice);
            this.Controls.Add(this.lblPartySize);
            this.Controls.Add(this.lblComboSelection);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.lblReservation);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form4";
            this.Text = "Receipt";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblReservation;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTotalPrice;
        private System.Windows.Forms.Label lblComboSelection;
        private System.Windows.Forms.Label lblPartySize;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblUserDisplay;
    }
}