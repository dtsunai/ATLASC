﻿
namespace AltasC
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSelectTime = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnComfirm = new System.Windows.Forms.Button();
            this.ra6pm = new System.Windows.Forms.RadioButton();
            this.ra8pm = new System.Windows.Forms.RadioButton();
            this.ra7pm = new System.Windows.Forms.RadioButton();
            this.ra9pm = new System.Windows.Forms.RadioButton();
            this.ra11pm = new System.Windows.Forms.RadioButton();
            this.ra10pm = new System.Windows.Forms.RadioButton();
            this.ra12pm = new System.Windows.Forms.RadioButton();
            this.ra2am = new System.Windows.Forms.RadioButton();
            this.ra1am = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lblSelectTime
            // 
            this.lblSelectTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSelectTime.AutoSize = true;
            this.lblSelectTime.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectTime.Location = new System.Drawing.Point(473, 165);
            this.lblSelectTime.Name = "lblSelectTime";
            this.lblSelectTime.Size = new System.Drawing.Size(255, 22);
            this.lblSelectTime.TabIndex = 15;
            this.lblSelectTime.Text = "Please Select Desired Date and Time";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker1.Location = new System.Drawing.Point(477, 227);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(251, 20);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // btnComfirm
            // 
            this.btnComfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnComfirm.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComfirm.Location = new System.Drawing.Point(636, 463);
            this.btnComfirm.Name = "btnComfirm";
            this.btnComfirm.Size = new System.Drawing.Size(92, 31);
            this.btnComfirm.TabIndex = 25;
            this.btnComfirm.Text = "Confirm";
            this.btnComfirm.UseVisualStyleBackColor = true;
            this.btnComfirm.Click += new System.EventHandler(this.btnComfirm_Click);
            // 
            // ra6pm
            // 
            this.ra6pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra6pm.AutoSize = true;
            this.ra6pm.Location = new System.Drawing.Point(477, 287);
            this.ra6pm.Name = "ra6pm";
            this.ra6pm.Size = new System.Drawing.Size(69, 17);
            this.ra6pm.TabIndex = 26;
            this.ra6pm.TabStop = true;
            this.ra6pm.Text = "6:00 p.m.";
            this.ra6pm.UseVisualStyleBackColor = true;
            this.ra6pm.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // ra8pm
            // 
            this.ra8pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra8pm.AutoSize = true;
            this.ra8pm.Location = new System.Drawing.Point(659, 286);
            this.ra8pm.Name = "ra8pm";
            this.ra8pm.Size = new System.Drawing.Size(69, 17);
            this.ra8pm.TabIndex = 26;
            this.ra8pm.TabStop = true;
            this.ra8pm.Text = "8:00 p.m.";
            this.ra8pm.UseVisualStyleBackColor = true;
            this.ra8pm.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // ra7pm
            // 
            this.ra7pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra7pm.AutoSize = true;
            this.ra7pm.Location = new System.Drawing.Point(569, 286);
            this.ra7pm.Name = "ra7pm";
            this.ra7pm.Size = new System.Drawing.Size(69, 17);
            this.ra7pm.TabIndex = 26;
            this.ra7pm.TabStop = true;
            this.ra7pm.Text = "7:00 p.m.";
            this.ra7pm.UseVisualStyleBackColor = true;
            this.ra7pm.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // ra9pm
            // 
            this.ra9pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra9pm.AutoSize = true;
            this.ra9pm.Location = new System.Drawing.Point(477, 345);
            this.ra9pm.Name = "ra9pm";
            this.ra9pm.Size = new System.Drawing.Size(69, 17);
            this.ra9pm.TabIndex = 26;
            this.ra9pm.TabStop = true;
            this.ra9pm.Text = "9:00 p.m.";
            this.ra9pm.UseVisualStyleBackColor = true;
            this.ra9pm.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // ra11pm
            // 
            this.ra11pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra11pm.AutoSize = true;
            this.ra11pm.Location = new System.Drawing.Point(659, 344);
            this.ra11pm.Name = "ra11pm";
            this.ra11pm.Size = new System.Drawing.Size(75, 17);
            this.ra11pm.TabIndex = 26;
            this.ra11pm.TabStop = true;
            this.ra11pm.Text = "11:00 p.m.";
            this.ra11pm.UseVisualStyleBackColor = true;
            this.ra11pm.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // ra10pm
            // 
            this.ra10pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra10pm.AutoSize = true;
            this.ra10pm.Location = new System.Drawing.Point(569, 344);
            this.ra10pm.Name = "ra10pm";
            this.ra10pm.Size = new System.Drawing.Size(75, 17);
            this.ra10pm.TabIndex = 26;
            this.ra10pm.TabStop = true;
            this.ra10pm.Text = "10:00 p.m.";
            this.ra10pm.UseVisualStyleBackColor = true;
            this.ra10pm.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // ra12pm
            // 
            this.ra12pm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra12pm.AutoSize = true;
            this.ra12pm.Location = new System.Drawing.Point(477, 399);
            this.ra12pm.Name = "ra12pm";
            this.ra12pm.Size = new System.Drawing.Size(75, 17);
            this.ra12pm.TabIndex = 26;
            this.ra12pm.TabStop = true;
            this.ra12pm.Text = "12:00 p.m.";
            this.ra12pm.UseVisualStyleBackColor = true;
            this.ra12pm.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // ra2am
            // 
            this.ra2am.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra2am.AutoSize = true;
            this.ra2am.Location = new System.Drawing.Point(659, 399);
            this.ra2am.Name = "ra2am";
            this.ra2am.Size = new System.Drawing.Size(69, 17);
            this.ra2am.TabIndex = 26;
            this.ra2am.TabStop = true;
            this.ra2am.Text = "2:00 a.m.";
            this.ra2am.UseVisualStyleBackColor = true;
            this.ra2am.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // ra1am
            // 
            this.ra1am.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ra1am.AutoSize = true;
            this.ra1am.Location = new System.Drawing.Point(569, 399);
            this.ra1am.Name = "ra1am";
            this.ra1am.Size = new System.Drawing.Size(69, 17);
            this.ra1am.TabIndex = 26;
            this.ra1am.TabStop = true;
            this.ra1am.Text = "1:00 a.m.";
            this.ra1am.UseVisualStyleBackColor = true;
            this.ra1am.CheckedChanged += new System.EventHandler(this.ra6pm_CheckedChanged);
            // 
            // Date
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 705);
            this.Controls.Add(this.ra1am);
            this.Controls.Add(this.ra10pm);
            this.Controls.Add(this.ra7pm);
            this.Controls.Add(this.ra2am);
            this.Controls.Add(this.ra11pm);
            this.Controls.Add(this.ra8pm);
            this.Controls.Add(this.ra12pm);
            this.Controls.Add(this.ra9pm);
            this.Controls.Add(this.ra6pm);
            this.Controls.Add(this.btnComfirm);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblSelectTime);
            this.Name = "Date";
            this.Text = "Date Time";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblSelectTime;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnComfirm;
        private System.Windows.Forms.RadioButton ra6pm;
        private System.Windows.Forms.RadioButton ra8pm;
        private System.Windows.Forms.RadioButton ra7pm;
        private System.Windows.Forms.RadioButton ra9pm;
        private System.Windows.Forms.RadioButton ra11pm;
        private System.Windows.Forms.RadioButton ra10pm;
        private System.Windows.Forms.RadioButton ra12pm;
        private System.Windows.Forms.RadioButton ra2am;
        private System.Windows.Forms.RadioButton ra1am;
    }
}