﻿
namespace AltasC
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSelectCombo = new System.Windows.Forms.Label();
            this.lblcomboC3 = new System.Windows.Forms.Label();
            this.lblcomboC2 = new System.Windows.Forms.Label();
            this.lblcomboC5 = new System.Windows.Forms.Label();
            this.lblcomboC4 = new System.Windows.Forms.Label();
            this.lblcomboA5 = new System.Windows.Forms.Label();
            this.lblcomboA4 = new System.Windows.Forms.Label();
            this.lblcomboB5 = new System.Windows.Forms.Label();
            this.lblcomboB4 = new System.Windows.Forms.Label();
            this.lblcomboB3 = new System.Windows.Forms.Label();
            this.lblcomboB2 = new System.Windows.Forms.Label();
            this.lblcomboC1 = new System.Windows.Forms.Label();
            this.lblcomboA3 = new System.Windows.Forms.Label();
            this.lblcomboB1 = new System.Windows.Forms.Label();
            this.lblcomboA2 = new System.Windows.Forms.Label();
            this.lblcomboA1 = new System.Windows.Forms.Label();
            this.lblThanksLogin = new System.Windows.Forms.Label();
            this.btnComfirm = new System.Windows.Forms.Button();
            this.ComboA = new System.Windows.Forms.ComboBox();
            this.ComboB = new System.Windows.Forms.ComboBox();
            this.ComboC = new System.Windows.Forms.ComboBox();
            this.chComboA = new System.Windows.Forms.CheckBox();
            this.chComboB = new System.Windows.Forms.CheckBox();
            this.chComboC = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblSelectCombo
            // 
            this.lblSelectCombo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSelectCombo.AutoSize = true;
            this.lblSelectCombo.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectCombo.Location = new System.Drawing.Point(89, 268);
            this.lblSelectCombo.Name = "lblSelectCombo";
            this.lblSelectCombo.Size = new System.Drawing.Size(208, 22);
            this.lblSelectCombo.TabIndex = 18;
            this.lblSelectCombo.Text = "Please Select Desired Combo";
            // 
            // lblcomboC3
            // 
            this.lblcomboC3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboC3.AutoSize = true;
            this.lblcomboC3.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboC3.Location = new System.Drawing.Point(1115, 627);
            this.lblcomboC3.Name = "lblcomboC3";
            this.lblcomboC3.Size = new System.Drawing.Size(235, 22);
            this.lblcomboC3.TabIndex = 17;
            this.lblcomboC3.Text = "Sweet and Sour Chicken Parmesan";
            // 
            // lblcomboC2
            // 
            this.lblcomboC2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboC2.AutoSize = true;
            this.lblcomboC2.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboC2.Location = new System.Drawing.Point(1115, 544);
            this.lblcomboC2.Name = "lblcomboC2";
            this.lblcomboC2.Size = new System.Drawing.Size(260, 22);
            this.lblcomboC2.TabIndex = 16;
            this.lblcomboC2.Text = "Chinese Meatballs with Marinara Sauce";
            // 
            // lblcomboC5
            // 
            this.lblcomboC5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboC5.AutoSize = true;
            this.lblcomboC5.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboC5.Location = new System.Drawing.Point(1115, 782);
            this.lblcomboC5.Name = "lblcomboC5";
            this.lblcomboC5.Size = new System.Drawing.Size(167, 22);
            this.lblcomboC5.TabIndex = 15;
            this.lblcomboC5.Text = "Mango Pudding Tiramisu ";
            // 
            // lblcomboC4
            // 
            this.lblcomboC4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboC4.AutoSize = true;
            this.lblcomboC4.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboC4.Location = new System.Drawing.Point(1115, 706);
            this.lblcomboC4.Name = "lblcomboC4";
            this.lblcomboC4.Size = new System.Drawing.Size(376, 22);
            this.lblcomboC4.TabIndex = 14;
            this.lblcomboC4.Text = "Italian-style Wonton Soup/Chinese-style Caprese Salad";
            // 
            // lblcomboA5
            // 
            this.lblcomboA5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboA5.AutoSize = true;
            this.lblcomboA5.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboA5.Location = new System.Drawing.Point(89, 782);
            this.lblcomboA5.Name = "lblcomboA5";
            this.lblcomboA5.Size = new System.Drawing.Size(164, 22);
            this.lblcomboA5.TabIndex = 19;
            this.lblcomboA5.Text = "Mango Pudding Tiramisu";
            // 
            // lblcomboA4
            // 
            this.lblcomboA4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboA4.AutoSize = true;
            this.lblcomboA4.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboA4.Location = new System.Drawing.Point(89, 706);
            this.lblcomboA4.Name = "lblcomboA4";
            this.lblcomboA4.Size = new System.Drawing.Size(376, 22);
            this.lblcomboA4.TabIndex = 4;
            this.lblcomboA4.Text = "Italian-style Wonton Soup/Chinese-style Caprese Salad";
            // 
            // lblcomboB5
            // 
            this.lblcomboB5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboB5.AutoSize = true;
            this.lblcomboB5.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboB5.Location = new System.Drawing.Point(616, 782);
            this.lblcomboB5.Name = "lblcomboB5";
            this.lblcomboB5.Size = new System.Drawing.Size(164, 22);
            this.lblcomboB5.TabIndex = 11;
            this.lblcomboB5.Text = "Mango Pudding Tiramisu";
            // 
            // lblcomboB4
            // 
            this.lblcomboB4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboB4.AutoSize = true;
            this.lblcomboB4.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboB4.Location = new System.Drawing.Point(616, 706);
            this.lblcomboB4.Name = "lblcomboB4";
            this.lblcomboB4.Size = new System.Drawing.Size(379, 22);
            this.lblcomboB4.TabIndex = 10;
            this.lblcomboB4.Text = " Italian-style Wonton Soup/Chinese-style Caprese Salad";
            // 
            // lblcomboB3
            // 
            this.lblcomboB3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboB3.AutoSize = true;
            this.lblcomboB3.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboB3.Location = new System.Drawing.Point(616, 627);
            this.lblcomboB3.Name = "lblcomboB3";
            this.lblcomboB3.Size = new System.Drawing.Size(143, 22);
            this.lblcomboB3.TabIndex = 9;
            this.lblcomboB3.Text = "Sesame seed risotto";
            // 
            // lblcomboB2
            // 
            this.lblcomboB2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboB2.AutoSize = true;
            this.lblcomboB2.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboB2.Location = new System.Drawing.Point(616, 544);
            this.lblcomboB2.Name = "lblcomboB2";
            this.lblcomboB2.Size = new System.Drawing.Size(143, 22);
            this.lblcomboB2.TabIndex = 8;
            this.lblcomboB2.Text = "Italian-style dumplings";
            // 
            // lblcomboC1
            // 
            this.lblcomboC1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboC1.AutoSize = true;
            this.lblcomboC1.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboC1.Location = new System.Drawing.Point(1115, 454);
            this.lblcomboC1.Name = "lblcomboC1";
            this.lblcomboC1.Size = new System.Drawing.Size(74, 22);
            this.lblcomboC1.TabIndex = 7;
            this.lblcomboC1.Text = "French 75";
            // 
            // lblcomboA3
            // 
            this.lblcomboA3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboA3.AutoSize = true;
            this.lblcomboA3.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboA3.Location = new System.Drawing.Point(89, 627);
            this.lblcomboA3.Name = "lblcomboA3";
            this.lblcomboA3.Size = new System.Drawing.Size(157, 22);
            this.lblcomboA3.TabIndex = 6;
            this.lblcomboA3.Text = "Orange chicken lasagna";
            // 
            // lblcomboB1
            // 
            this.lblcomboB1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboB1.AutoSize = true;
            this.lblcomboB1.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboB1.Location = new System.Drawing.Point(616, 454);
            this.lblcomboB1.Name = "lblcomboB1";
            this.lblcomboB1.Size = new System.Drawing.Size(122, 22);
            this.lblcomboB1.TabIndex = 5;
            this.lblcomboB1.Text = "Espresso Martini";
            // 
            // lblcomboA2
            // 
            this.lblcomboA2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboA2.AutoSize = true;
            this.lblcomboA2.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboA2.Location = new System.Drawing.Point(89, 544);
            this.lblcomboA2.Name = "lblcomboA2";
            this.lblcomboA2.Size = new System.Drawing.Size(272, 22);
            this.lblcomboA2.TabIndex = 12;
            this.lblcomboA2.Text = " Fried Calamari (Sweet and Sour Sauce)";
            // 
            // lblcomboA1
            // 
            this.lblcomboA1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcomboA1.AutoSize = true;
            this.lblcomboA1.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomboA1.Location = new System.Drawing.Point(89, 454);
            this.lblcomboA1.Name = "lblcomboA1";
            this.lblcomboA1.Size = new System.Drawing.Size(100, 22);
            this.lblcomboA1.TabIndex = 13;
            this.lblcomboA1.Text = "Aperol Spritz";
            // 
            // lblThanksLogin
            // 
            this.lblThanksLogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblThanksLogin.AutoSize = true;
            this.lblThanksLogin.Font = new System.Drawing.Font("Papyrus", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThanksLogin.Location = new System.Drawing.Point(613, 157);
            this.lblThanksLogin.Name = "lblThanksLogin";
            this.lblThanksLogin.Size = new System.Drawing.Size(318, 42);
            this.lblThanksLogin.TabIndex = 23;
            this.lblThanksLogin.Text = "Thank You for Loging in.";
            // 
            // btnComfirm
            // 
            this.btnComfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnComfirm.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComfirm.Location = new System.Drawing.Point(1374, 939);
            this.btnComfirm.Name = "btnComfirm";
            this.btnComfirm.Size = new System.Drawing.Size(117, 33);
            this.btnComfirm.TabIndex = 24;
            this.btnComfirm.Text = "Confirm";
            this.btnComfirm.UseVisualStyleBackColor = true;
            this.btnComfirm.Click += new System.EventHandler(this.btnComfirm_Click);
            // 
            // ComboA
            // 
            this.ComboA.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ComboA.FormattingEnabled = true;
            this.ComboA.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.ComboA.Location = new System.Drawing.Point(211, 376);
            this.ComboA.Name = "ComboA";
            this.ComboA.Size = new System.Drawing.Size(42, 21);
            this.ComboA.TabIndex = 25;
            // 
            // ComboB
            // 
            this.ComboB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ComboB.FormattingEnabled = true;
            this.ComboB.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.ComboB.Location = new System.Drawing.Point(738, 376);
            this.ComboB.Name = "ComboB";
            this.ComboB.Size = new System.Drawing.Size(42, 21);
            this.ComboB.TabIndex = 25;
            // 
            // ComboC
            // 
            this.ComboC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ComboC.FormattingEnabled = true;
            this.ComboC.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.ComboC.Location = new System.Drawing.Point(1240, 376);
            this.ComboC.Name = "ComboC";
            this.ComboC.Size = new System.Drawing.Size(42, 21);
            this.ComboC.TabIndex = 25;
            // 
            // chComboA
            // 
            this.chComboA.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chComboA.AutoSize = true;
            this.chComboA.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chComboA.Location = new System.Drawing.Point(93, 374);
            this.chComboA.Name = "chComboA";
            this.chComboA.Size = new System.Drawing.Size(95, 26);
            this.chComboA.TabIndex = 26;
            this.chComboA.Text = "Combo A";
            this.chComboA.UseVisualStyleBackColor = true;
            // 
            // chComboB
            // 
            this.chComboB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chComboB.AutoSize = true;
            this.chComboB.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chComboB.Location = new System.Drawing.Point(620, 374);
            this.chComboB.Name = "chComboB";
            this.chComboB.Size = new System.Drawing.Size(95, 26);
            this.chComboB.TabIndex = 26;
            this.chComboB.Text = "Combo B";
            this.chComboB.UseVisualStyleBackColor = true;
            // 
            // chComboC
            // 
            this.chComboC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chComboC.AutoSize = true;
            this.chComboC.Font = new System.Drawing.Font("Papyrus", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chComboC.Location = new System.Drawing.Point(1119, 374);
            this.chComboC.Name = "chComboC";
            this.chComboC.Size = new System.Drawing.Size(95, 26);
            this.chComboC.TabIndex = 26;
            this.chComboC.Text = "Combo C";
            this.chComboC.UseVisualStyleBackColor = true;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1619, 1148);
            this.Controls.Add(this.chComboC);
            this.Controls.Add(this.chComboB);
            this.Controls.Add(this.chComboA);
            this.Controls.Add(this.ComboC);
            this.Controls.Add(this.ComboB);
            this.Controls.Add(this.ComboA);
            this.Controls.Add(this.btnComfirm);
            this.Controls.Add(this.lblThanksLogin);
            this.Controls.Add(this.lblSelectCombo);
            this.Controls.Add(this.lblcomboC3);
            this.Controls.Add(this.lblcomboC2);
            this.Controls.Add(this.lblcomboC5);
            this.Controls.Add(this.lblcomboC4);
            this.Controls.Add(this.lblcomboA5);
            this.Controls.Add(this.lblcomboA4);
            this.Controls.Add(this.lblcomboB5);
            this.Controls.Add(this.lblcomboB4);
            this.Controls.Add(this.lblcomboB3);
            this.Controls.Add(this.lblcomboB2);
            this.Controls.Add(this.lblcomboC1);
            this.Controls.Add(this.lblcomboA3);
            this.Controls.Add(this.lblcomboB1);
            this.Controls.Add(this.lblcomboA2);
            this.Controls.Add(this.lblcomboA1);
            this.Name = "Menu";
            this.Text = "Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblSelectCombo;
        private System.Windows.Forms.Label lblcomboC3;
        private System.Windows.Forms.Label lblcomboC2;
        private System.Windows.Forms.Label lblcomboC5;
        private System.Windows.Forms.Label lblcomboC4;
        private System.Windows.Forms.Label lblcomboA5;
        private System.Windows.Forms.Label lblcomboA4;
        private System.Windows.Forms.Label lblcomboB5;
        private System.Windows.Forms.Label lblcomboB4;
        private System.Windows.Forms.Label lblcomboB3;
        private System.Windows.Forms.Label lblcomboB2;
        private System.Windows.Forms.Label lblcomboC1;
        private System.Windows.Forms.Label lblcomboA3;
        private System.Windows.Forms.Label lblcomboB1;
        private System.Windows.Forms.Label lblcomboA2;
        private System.Windows.Forms.Label lblcomboA1;
        private System.Windows.Forms.Label lblThanksLogin;
        private System.Windows.Forms.Button btnComfirm;
        private System.Windows.Forms.ComboBox ComboA;
        private System.Windows.Forms.ComboBox ComboB;
        private System.Windows.Forms.ComboBox ComboC;
        private System.Windows.Forms.CheckBox chComboA;
        private System.Windows.Forms.CheckBox chComboB;
        private System.Windows.Forms.CheckBox chComboC;
    }
}