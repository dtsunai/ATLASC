﻿// UPDATED FILE #1
// WORKING ACCOUNTID AND PASSWORD LOGIN
// TRANSFER INFORMATION FROM FORM 1 TO FORM 4
// NEXT: WORKING ON **ALL** RECEIPT DETAILS
// STORING INFORMATION FOR IMPORT BEFORE USER INTERACTION
// SUGGESTION, PLEASE CHANGE COMBO TO MENU >>

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AltasC
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            const string USER_FILE = "UserInfo.txt";
            const string PASS_FILE = "PasswordInfo.txt";

            FileStream fsIn = new FileStream(USER_FILE, FileMode.Open,FileAccess.Read);
            StreamReader srIn = new StreamReader(fsIn);
            string userID = srIn.ReadLine();

            Form4 receipt = new Form4(txtID.Text);

            if (userID == txtID.Text)
            {
                FileStream fsIn2 = new FileStream(PASS_FILE, FileMode.Open, FileAccess.Read);
                StreamReader srIn2 = new StreamReader(fsIn2);
                string passID = srIn2.ReadLine();

                if (passID == txtPassword.Text)
                {
                    this.Hide();
                    string userInput = txtID.Text;


                    Form2 menuSelection = new Form2(userInput);
                    menuSelection.Show();
                }
                else
                {
                    MessageBox.Show("Incorrect password");
                }

            }

            else
            {
                MessageBox.Show("Incorrect login");
            }

            //string dataToSend = txtID.Text;
            //form4.UserInput = txtID.Text;
            //form4.Data = dataToSend;

        }
    }
}
